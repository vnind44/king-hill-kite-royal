package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColorScheme = lightColorScheme(
  primary = PrimaryDark,
  onPrimary = OnPrimary,
  primaryContainer = PrimaryContainer,
  onPrimaryContainer = OnPrimaryContainer,
  secondary = SecondaryTeal,
  onSecondary = OnSecondary,
  secondaryContainer = SecondaryContainer,
  onSecondaryContainer = OnSecondaryContainer,
  tertiary = OnTertiaryContainer,
  onTertiary = OnPrimary,
  surface = SurfaceColor,
  onSurface = OnSurface,
  surfaceVariant = SurfaceContainerHigh,
  onSurfaceVariant = OnSurfaceVariant,
  surfaceContainer = SurfaceContainer,
  surfaceContainerLow = SurfaceContainerLow,
  surfaceContainerLowest = SurfaceContainerLowest,
  surfaceContainerHigh = SurfaceContainerHigh,
  surfaceContainerHighest = SurfaceContainerHighest,
  outline = Outline,
  outlineVariant = OutlineVariant,
  error = ErrorRed,
  onError = OnPrimary,
  errorContainer = ErrorContainer,
  onErrorContainer = OnErrorContainer,
  inverseSurface = InverseSurface,
  inverseOnSurface = InverseOnSurface
)

private val DarkColorScheme = darkColorScheme(
  primary = SecondaryFixed,
  onPrimary = PrimaryDark,
  primaryContainer = PrimaryContainer,
  onPrimaryContainer = SurfaceContainerHigh,
  secondary = SecondaryContainer,
  onSecondary = PrimaryDark,
  secondaryContainer = SecondaryTeal,
  onSecondaryContainer = SecondaryFixed,
  surface = InverseSurface,
  onSurface = InverseOnSurface,
  surfaceVariant = PrimaryContainer,
  onSurfaceVariant = SurfaceDim,
  surfaceContainer = InverseSurface,
  surfaceContainerLow = PrimaryContainer,
  surfaceContainerLowest = PrimaryDark,
  outline = OutlineVariant,
  outlineVariant = Outline
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val baseColorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
  val customBg = AppThemeState.currentBackgroundColor
  val isDarkBg = AppThemeState.isDarkBackground

  val colorScheme = baseColorScheme.copy(
    surface = customBg,
    background = customBg,
    surfaceContainer = if (isDarkBg) customBg else SurfaceContainer,
    onSurface = if (isDarkBg) androidx.compose.ui.graphics.Color(0xFFF1F5F9) else OnSurface,
    onSurfaceVariant = if (isDarkBg) androidx.compose.ui.graphics.Color(0xFFCBD5E1) else OnSurfaceVariant
  )
  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}


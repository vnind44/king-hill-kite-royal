package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.SampleData
import com.example.model.CampusReportItem
import com.example.ui.theme.*

@Composable
fun ReportItemDialog(
    onDismiss: () -> Unit,
    onReportSubmitted: (CampusReportItem) -> Unit
) {
    var reportType by remember { mutableStateOf("Lost") } // "Lost" or "Found"
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Electronics") }
    var location by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var serialNumber by remember { mutableStateOf("") }

    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = if (reportType == "Lost") Icons.Default.Search else Icons.Default.AddLocationAlt,
                    contentDescription = null,
                    tint = SecondaryTeal
                )
                Text(
                    text = "Report Campus Item",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Type selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = reportType == "Lost",
                        onClick = { reportType = "Lost" },
                        label = { Text("I Lost Something", fontWeight = FontWeight.Bold) },
                        modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryDark,
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = reportType == "Found",
                        onClick = { reportType = "Found" },
                        label = { Text("I Found Something", fontWeight = FontWeight.Bold) },
                        modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SecondaryTeal,
                            selectedLabelColor = Color.White
                        )
                    )
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Item Name / Description") },
                    placeholder = { Text("e.g. Hydro Flask Navy Blue 32oz") },
                    modifier = Modifier.fillMaxWidth().testTag("report_title_input"),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Campus Location") },
                    placeholder = { Text("e.g. Green Library 2nd Floor") },
                    modifier = Modifier.fillMaxWidth().testTag("report_location_input"),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Details & Distinctive Marks") },
                    placeholder = { Text("Color, stickers, scratches, case type...") },
                    modifier = Modifier.fillMaxWidth().testTag("report_desc_input"),
                    shape = RoundedCornerShape(10.dp),
                    minLines = 2
                )

                OutlinedTextField(
                    value = serialNumber,
                    onValueChange = { serialNumber = it },
                    label = { Text("Serial Number or ID (Optional & Encrypted)") },
                    placeholder = { Text("Shielded from public view") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank() || location.isBlank()) {
                        Toast.makeText(context, "Please enter item title and location", Toast.LENGTH_SHORT).show()
                    } else {
                        val newItem = CampusReportItem(
                            id = "item_${System.currentTimeMillis()}",
                            title = title,
                            category = category,
                            isLost = (reportType == "Lost"),
                            statusBadge = if (reportType == "Lost") "SEARCHING" else "UNDER REVIEW",
                            reportedBy = "Alex Rivera (Engineering)",
                            location = location,
                            timeAgo = "Just now",
                            imageUrl = SampleData.SONY_EARBUDS_URL,
                            authClaimCode = "849-${(100..999).random()}",
                            description = description.ifBlank { "Reported at $location" }
                        )
                        onReportSubmitted(newItem)
                        Toast.makeText(context, "Report posted! Smart match beacons active.", Toast.LENGTH_LONG).show()
                    }
                },
                modifier = Modifier.testTag("submit_report_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = SecondaryTeal)
            ) {
                Text("Submit Report", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

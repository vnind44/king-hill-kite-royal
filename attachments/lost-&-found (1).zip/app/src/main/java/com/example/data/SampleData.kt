package com.example.data

import com.example.model.CampusNotification
import com.example.model.CampusReportItem
import com.example.model.CustodyDesk
import com.example.model.UserProfile

object SampleData {

    const val APP_LOGO_URL = "https://lh3.googleusercontent.com/aida/AEtjO1UUm1xjzwbaWRBrbY1PT_H4Mre09NLbF1U-kYk2qaKH-uYjs9DaOqMLCNnM1JyWcI97vM51To6B5fPe9Ly3fakGIyZw-spP-Fwa94k-lPBWpcPoTyXnd4d_F9FRmedPSmoTmWa5AJu6mKctaQSTDaXyGWl2sIaCF65H-IGEgWLBvq7UuL-9kjTdzumxapHVPI-RR5nvcnoFtgiJPSd_3VwhRQKAe1guZ7HAdD6IlaQ1p1r2oAXWWMNkXNc"

    const val CAMPUS_HERO_URL = "https://lh3.googleusercontent.com/aida-public/AB6AXuDFVbgjvab2noDjU6z7Ojm319Now0hlyBYCpJVRpdZVsniOfy-h0J2eADTlrycuxbxLjDKUsFY8MfPlSL0k46W5qQC92Njqo1Er-JNoS8V3iJNlgE6e2edNtEXzhIxzqeGz62uDnyMlYG9oHeNF7yIbQ45WUpZW3FYTXNlPvr7hOiSih9ezjyZg41BGAm5g-XCEqpUr-td4Dyiw0RhYd7rFR5sOHYnjbdbFA7lL6uUrf1OkchVcOEf3"

    const val USER_AVATAR_URL = "https://lh3.googleusercontent.com/aida/AEtjO1XdHaItYMdTmmw7cmVJ8sOmwlIpJ1oQQ4AD7gQ-iC8r_5M7dA0uQsP2ClFPtzS9HE3230f1U3Oo6sDojUlUR-iCo4mX7T95IjpxLZPMm2pgNHk-Avm0SiTedslwgYwSZCuQ_sVuYjMXMA5zopV6MlLX3zQ52duzjcAP7eErV76hHQF-8qnG7Fvq_ZF-3rsWLdKBeZ7AnhnWcEwSem0-PS4wIEgduF1QTJ9qE7R69sJ_ggXbjQcNlewxMQ"

    const val WILDCRAFT_BACKPACK_URL = "https://lh3.googleusercontent.com/aida-public/AB6AXuB0QwFa8d1C9hLeAH_XtRzXwuA8plLODWtQ0WjwtLhjNcPd-cz_m8dUT00LQf591B2FeDa7lqN2geNlKveCX6cbr1BUvaZgj8Ko51KKcCK3ABbojJDgusHtTo2OQbra4aLlkJl3gI-tzD6giLqsGNP0NdKBiVX_dgItJoTEIplINGfomWDeUNLg4B9pUVEbnjpcwS9ZR5NZGQxDyMdyHoz-t4w8h0RwEnjC03MJEciJJotJDnOEwVuP"

    const val WILDCRAFT_IN_LIBRARY_URL = "https://lh3.googleusercontent.com/aida-public/AB6AXuAAF6TFog2VVbAVGVirUpOsBZfKegwkeAiSbi8MGUgJV64F4KuUSaAqRztwNt7cakkHptg5yMGhRIQ6SqLkMjV1keCLTh5t6wIUmTI_45g8qLNG2v53F_3t0mJdBvyHqlarY0q-biXZZUAaX_9zGasHxiGFPAjDiNG7gn_ysVNuUR48DYgGQlVlBZLSR8IeV7Cn1mWV46aXgrHANmEuQ9yQiKqSrPdNwDHlL1tWbi0xBTgufvnxbRyR"

    const val SONY_EARBUDS_URL = "https://lh3.googleusercontent.com/aida-public/AB6AXuDjunlrAlIbkxncVzHwk-VOPMVrpeg1GQVZIjb02iGGN4QAEEecpynzywtbDzENUlQHe9nZzvBunJ3ZXiaryNV06F1nerSQ5jvFVJkzxpmPgP32CUFO5CLHSEbf9tjveNCCSW5mlc3-t9FHQVu_3Ogi5bmh_hz4TkidzZY7jRD64I4_RhxYJwdZL612ns1vHORcVhQ6Kh4Q8lZY3YirbrOQWRtRnaMGs8Ozo6-DQP1HNz0_sT5v-aX2"

    const val HYDRO_FLASK_URL = "https://lh3.googleusercontent.com/aida-public/AB6AXuD6ddzAr6pvE-Bec2JlhOt7_bvZS0nn3ECORPw2bdUIuWieJE4Y-sWEZ1m47JHNjwY2UqmsQpPeEwxmZn1ewaW18oJpHTAXy-vk6jRNT81FFm5GNiM0nwgszefEigpMRP72bHcKovaC-MLOHxzRt82Q1LHgOIGDunWeeGRROrZHaX2HDESTMc223v3XbpRb7Sf1Yjy78AJ6JANvP6PHjZplqg7jcaYCudzwiPDROrKucLkr8Bzj5E1c"

    const val STUDENT_ID_URL = "https://lh3.googleusercontent.com/aida-public/AB6AXuApMDZbbhDMABrDYxEXfE1QVkbHwvHoFH3_I5lanPzncaM8o6HnBA5l_AKoafFmJaax9lgbu4r6vQAaDZtYMsdgF5Sz4OcoxsYNlLJG1t27W_gIjM3gA_v89dctLyJ1auZdPvSOvRQEr8SzucBlm1qqKR_Yf67Xiqd3jTdFFvtOHyvapEl7o1Q-Mq-vReATAl4flgl2w1PKDHfPG_IAaCPtjW2fdH8FaZzPk1TSgxzK_f9PH2IkdH5A"

    const val OFFICER_MILLER_URL = "https://lh3.googleusercontent.com/aida-public/AB6AXuBv6wiZjLrktWbiLPRuawIoH-4fTswyz6r1KXm7TgyO6sT4LBLYLX6DASv-v0qdKnS-Mn50ivj9iVZNqbsdgzvcVztLrs0E7b00laZIUIVktvzvAUQqBEZQdy4zEpnZqngsZ4t7L77nzhxBXmPkoeHZ8AMdFraeaKBw1ms3JhY33wYi_zaAioohwrOnvDAJigzE08UPVNYzhoOoWTpMwwr8WYtVYOgnPLu5Wh2Dv99s2M07HzZ26JLt"

    const val TRESSIDER_DESK_URL = "https://lh3.googleusercontent.com/aida-public/AB6AXuDALJkajM65wArYRyozaSnC7qyYtfshlnCFkk728JKMghm0fr1sb_tov6YMzFCX0t6NA8kMwdYP2AzpPrRjgfhdevGFEULHnZUVEAFWUIwhpR9Qusz6zJK-lKVbg7pAfGCCKBFi9-hD_ITlojkv81kkYoEejE7JH7wHtcyO_UZpYchoX0V6mVQl7fPdWgt5A6en5yg8_R2wspgRda226UiqqH2RKzsMQgQRdVuIDRfqoVDST1QyTYny"

    val defaultProfile = UserProfile(
        name = "Alex Rivera",
        role = "School of Engineering • B.S. CS '27",
        email = "alex.rivera@stanford.edu",
        phone = "(650) 842-9102",
        studentId = "•••• 4892",
        residence = "Crothers Hall (East Campus)",
        karmaPoints = 420,
        maxKarmaPoints = 500,
        tier = "Tier 3 Guardian",
        trustScore = 100,
        itemsReturned = 4,
        recoveredItems = 2,
        honorCompliance = 100,
        falseClaims = 0,
        avatarUrl = USER_AVATAR_URL
    )

    val custodyDesks = listOf(
        CustodyDesk(
            id = "green-lib",
            name = "Green Library Safe Desk (Wing B)",
            location = "Ground Floor Central Atrium, Adjacent to Help Desk",
            hours = "OPEN • Closes at 8:00 PM",
            isOpen = true,
            tag = "Primary Hub",
            vaultCount = 14,
            lockerNote = "3 smart lockers ready",
            staffName = "Officer Miller",
            staffRole = "Student Services",
            staffImageUrl = OFFICER_MILLER_URL,
            hasPinLockers = true,
            detailNotes = "Equipped with 24/7 digital tamper logs, CCTV, and automated pickup lockers."
        ),
        CustodyDesk(
            id = "tresidder",
            name = "Tresidder Student Union Info Hub",
            location = "1st Floor Welcome Desk, North Lobby",
            hours = "OPEN • Closes at 10:00 PM",
            isOpen = true,
            tag = null,
            vaultCount = 9,
            lockerNote = "Walk-in Ready",
            staffName = "Attendant On Duty",
            staffRole = "Campus Staff",
            staffImageUrl = TRESSIDER_DESK_URL,
            hasPinLockers = true,
            detailNotes = "Fast verification and safe public meeting handoff tables."
        ),
        CustodyDesk(
            id = "huang-eng",
            name = "Huang Engineering Student Lounge",
            location = "Room 102 (Staff Reception Desk)",
            hours = "OPEN • Closes at 6:00 PM",
            isOpen = true,
            tag = null,
            vaultCount = 4,
            lockerNote = "Tech specialist present • Fast Scan",
            staffName = "Engineering Support",
            staffRole = "Tech Custody",
            hasPinLockers = true,
            detailNotes = "Specialized hardware inspection tools, ESD-safe containment, serial scanners."
        ),
        CustodyDesk(
            id = "sudps",
            name = "Department of Public Safety (SUDPS)",
            location = "711 Serra St. Central Campus Gateway",
            hours = "OPEN 24/7",
            isOpen = true,
            tag = "High Value",
            vaultCount = 18,
            lockerNote = "Dual-officer signoff required",
            isHighValue = true,
            is24Hours = true,
            hasPinLockers = true,
            detailNotes = "Reserved custody for laptops, biometric devices, jewelry, vehicle keys, and government credentials."
        )
    )

    val activeReports = androidx.compose.runtime.mutableStateListOf(
        CampusReportItem(
            id = "LF-F-2026-8942",
            title = "Wildcraft Black Backpack",
            category = "Bags & Luggage",
            isLost = false,
            statusBadge = "READY FOR PICKUP",
            reportedBy = "Jordan M. (Engineering)",
            location = "Green Library • Front Information Desk",
            timeAgo = "12m ago",
            imageUrl = WILDCRAFT_BACKPACK_URL,
            authClaimCode = "849-210",
            isReadyForPickup = true
        ),
        CampusReportItem(
            id = "LF-L-2026-1042",
            title = "Sony WF-C500 Earbuds",
            category = "Electronics",
            isLost = true,
            statusBadge = "82% SMART MATCH FOUND",
            reportedBy = "Alex Rivera (You)",
            location = "Turned in at IT Block Lab 3",
            timeAgo = "1h ago",
            imageUrl = SONY_EARBUDS_URL,
            authClaimCode = "642-108",
            similarity = 82,
            matchDetails = "White Case • Reported lost at IT Block. Match criteria: Model, color & drop zone"
        ),
        CampusReportItem(
            id = "LF-F-2026-6410",
            title = "Hydro Flask 32oz Navy",
            category = "Accessories",
            isLost = false,
            statusBadge = "RETURNED",
            reportedBy = "Returned to Marcus K. • Student Union",
            location = "Student Union Desk",
            timeAgo = "Sep 8, 2026",
            imageUrl = HYDRO_FLASK_URL,
            authClaimCode = "LF-F-0491",
            isReturned = true,
            receiptVerifiedText = "Custody signed & verified by Officer Vance"
        ),
        CampusReportItem(
            id = "LF-L-2026-5821",
            title = "Stanford Student ID Card",
            category = "ID Cards",
            isLost = true,
            statusBadge = "RETURNED",
            reportedBy = "Alex Rivera (You)",
            location = "Security Dispatch Desk",
            timeAgo = "Sep 5, 2026",
            imageUrl = STUDENT_ID_URL,
            authClaimCode = "LF-L-5821",
            isReturned = true,
            receiptVerifiedText = "Biometric ID matched"
        )
    )

    fun addReport(item: CampusReportItem) {
        activeReports.add(0, item)
    }

    val notifications = listOf(
        CampusNotification(
            id = "notif-1",
            typeBadge = "Match Alert",
            title = "Possible Match Found!",
            description = "A Wildcraft Black Backpack found at Green Library matches your reported lost item by 82% similarity.",
            timeAgo = "10m ago",
            isUrgent = true,
            similarity = 82,
            imageUrl = WILDCRAFT_IN_LIBRARY_URL,
            locationText = "Green Library, Desk 402",
            finderInfo = "Reported by Finder: Lab Assistant Elena",
            pinCode = "849-210"
        ),
        CampusNotification(
            id = "notif-2",
            typeBadge = "Claim Approved",
            title = "Ownership Claim Approved",
            description = "Jordan M. has approved your claim for the Black Backpack. Your secure 6-digit pickup PIN is now active.",
            timeAgo = "1h ago",
            pinCode = "739-204",
            hasPinAction = true
        ),
        CampusNotification(
            id = "notif-3",
            typeBadge = "Community Good",
            title = "+50 Campus Karma Earned!",
            description = "Thanks for reporting a found Student ID card. The verified owner was notified immediately and picked it up safely.",
            timeAgo = "3h ago",
            karmaPointsText = "Tier 3 Guardian (420 pts)"
        ),
        CampusNotification(
            id = "notif-4",
            typeBadge = "Resolved",
            title = "Item Handover Completed",
            description = "Hydro Flask 32oz was marked as safely returned at Student Union Desk. Case #LF-F-0491 is now closed.",
            timeAgo = "Sep 8",
            isEarlierThisWeek = true,
            finderInfo = "Handoff confirmed by Campus Safety Officer Vance"
        ),
        CampusNotification(
            id = "notif-5",
            typeBadge = "Guidelines",
            title = "Honor Code & Handover Safety",
            description = "Always perform safe handovers at designated Campus Custody Desks or well-lit security kiosks. Never exchange high-value electronics in unmonitored dorms.",
            timeAgo = "Sep 6",
            isEarlierThisWeek = true,
            hasDeskAction = true
        )
    )
}

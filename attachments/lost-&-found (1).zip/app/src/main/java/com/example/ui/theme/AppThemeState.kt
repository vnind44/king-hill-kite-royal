package com.example.ui.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

data class BackgroundPreset(
    val name: String,
    val color: Color,
    val category: String = "Popular"
)

object AppThemeState {
    val DefaultColor = Color(0xFFF8F9FF)

    var currentBackgroundColor by mutableStateOf(DefaultColor)

    val isDarkBackground: Boolean
        get() {
            val lum = (currentBackgroundColor.red * 0.299f + 
                       currentBackgroundColor.green * 0.587f + 
                       currentBackgroundColor.blue * 0.114f)
            return lum < 0.5f
        }

    val presets = listOf(
        BackgroundPreset("Default Cloud", Color(0xFFF8F9FF), "Collegiate"),
        BackgroundPreset("Warm Sand", Color(0xFFFFFBEB), "Warm"),
        BackgroundPreset("Soft Mint", Color(0xFFF0FDF4), "Nature"),
        BackgroundPreset("Ice Sky", Color(0xFFF0F9FF), "Collegiate"),
        BackgroundPreset("Lavender Mist", Color(0xFFFAF5FF), "Creative"),
        BackgroundPreset("Rose Blush", Color(0xFFFFF1F2), "Warm"),
        BackgroundPreset("Muted Slate", Color(0xFFF1F5F9), "Collegiate"),
        BackgroundPreset("Champagne", Color(0xFFFEF9EE), "Warm"),
        BackgroundPreset("Deep Midnight", Color(0xFF0B1C30), "Dark"),
        BackgroundPreset("Charcoal Night", Color(0xFF121826), "Dark"),
        BackgroundPreset("Forest Obsidian", Color(0xFF071F1A), "Dark"),
        BackgroundPreset("Plum Dusk", Color(0xFF1E102A), "Dark")
    )

    fun setBackgroundColor(color: Color) {
        currentBackgroundColor = color
    }

    fun resetToDefault() {
        currentBackgroundColor = DefaultColor
    }

    fun colorToHex(color: Color): String {
        val r = (color.red * 255).toInt().coerceIn(0, 255)
        val g = (color.green * 255).toInt().coerceIn(0, 255)
        val b = (color.blue * 255).toInt().coerceIn(0, 255)
        return String.format("#%02X%02X%02X", r, g, b)
    }

    fun hexToColor(hex: String): Color? {
        return try {
            val cleanHex = hex.removePrefix("#").trim()
            if (cleanHex.length == 6) {
                val colorInt = cleanHex.toLong(16).toInt() or 0xFF000000.toInt()
                Color(colorInt)
            } else null
        } catch (e: Exception) {
            null
        }
    }
}

package com.example.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.example.data.SampleData
import com.example.ui.components.CampusBottomNavBar
import com.example.ui.components.ReportItemDialog
import com.example.ui.screens.*
import com.example.ui.theme.AppThemeState

object Routes {
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val OTP = "otp"
    const val IDENTITY_VERIFIED = "identity_verified"
    const val HOME = "home"
    const val SEARCH = "search"
    const val DESKS = "desks"
    const val ACTIVITY = "activity"
    const val PROFILE = "profile"
    const val NOTIFICATIONS = "notifications"
    const val PRIVACY_SECURITY = "privacy_security"
    const val NOTIFICATION_PREFERENCES = "notification_preferences"
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    var showReportDialog by remember { mutableStateOf(false) }

    // Check if bottom bar should be shown
    val bottomBarRoutes = listOf(
        Routes.HOME,
        Routes.SEARCH,
        Routes.DESKS,
        Routes.ACTIVITY,
        Routes.PROFILE
    )
    val shouldShowBottomBar = currentRoute in bottomBarRoutes

    Scaffold(
        containerColor = AppThemeState.currentBackgroundColor,
        bottomBar = {
            if (shouldShowBottomBar && currentRoute != null) {
                val currentTab = when (currentRoute) {
                    Routes.HOME -> com.example.ui.components.NavigationTab.HOME
                    Routes.SEARCH -> com.example.ui.components.NavigationTab.SEARCH
                    Routes.ACTIVITY -> com.example.ui.components.NavigationTab.ACTIVITY
                    Routes.PROFILE -> com.example.ui.components.NavigationTab.PROFILE
                    else -> com.example.ui.components.NavigationTab.HOME
                }
                CampusBottomNavBar(
                    currentTab = currentTab,
                    onTabSelected = { tab ->
                        val targetRoute = when (tab) {
                            com.example.ui.components.NavigationTab.HOME -> Routes.HOME
                            com.example.ui.components.NavigationTab.SEARCH -> Routes.SEARCH
                            com.example.ui.components.NavigationTab.REPORT -> Routes.HOME
                            com.example.ui.components.NavigationTab.ACTIVITY -> Routes.ACTIVITY
                            com.example.ui.components.NavigationTab.PROFILE -> Routes.PROFILE
                        }
                        navController.navigate(targetRoute) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onReportClick = {
                        showReportDialog = true
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(AppThemeState.currentBackgroundColor)
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = Routes.HOME // start at Home for instant exploration
            ) {
                // Screen 1: Login
                composable(Routes.LOGIN) {
                    LoginScreen(
                        onSignInSuccess = {
                            navController.navigate(Routes.OTP)
                        },
                        onNavigateToRegister = {
                            navController.navigate(Routes.REGISTER)
                        },
                        onNavigateToOtp = {
                            navController.navigate(Routes.OTP)
                        }
                    )
                }

                // Screen 2: Register
                composable(Routes.REGISTER) {
                    RegisterScreen(
                        onNavigateToOtp = {
                            navController.navigate(Routes.OTP)
                        },
                        onNavigateToLogin = {
                            navController.navigate(Routes.LOGIN) {
                                popUpTo(Routes.REGISTER) { inclusive = true }
                            }
                        },
                        onBackPressed = {
                            navController.popBackStack()
                        }
                    )
                }

                // Screen 3: OTP Verification
                composable(Routes.OTP) {
                    OtpScreen(
                        onVerificationSuccess = {
                            navController.navigate(Routes.IDENTITY_VERIFIED) {
                                popUpTo(Routes.OTP) { inclusive = true }
                            }
                        },
                        onBackPressed = {
                            navController.popBackStack()
                        }
                    )
                }

                // Screen 4: Identity Verified
                composable(Routes.IDENTITY_VERIFIED) {
                    IdentityVerifiedScreen(
                        onContinueToSearch = {
                            navController.navigate(Routes.SEARCH) {
                                popUpTo(Routes.IDENTITY_VERIFIED) { inclusive = true }
                            }
                        },
                        onGoToHome = {
                            navController.navigate(Routes.HOME) {
                                popUpTo(Routes.IDENTITY_VERIFIED) { inclusive = true }
                            }
                        }
                    )
                }

                // Screen: Home Feed
                composable(Routes.HOME) {
                    HomeScreen(
                        onNavigateToNotifications = {
                            navController.navigate(Routes.NOTIFICATIONS)
                        },
                        onNavigateToProfile = {
                            navController.navigate(Routes.PROFILE)
                        },
                        onNavigateToDesks = {
                            navController.navigate(Routes.DESKS)
                        },
                        onNavigateToActivity = {
                            navController.navigate(Routes.ACTIVITY)
                        },
                        onReportClick = {
                            showReportDialog = true
                        }
                    )
                }

                // Screen: Search Feed
                composable(Routes.SEARCH) {
                    SearchScreen(
                        onNavigateToNotifications = {
                            navController.navigate(Routes.NOTIFICATIONS)
                        },
                        onNavigateToProfile = {
                            navController.navigate(Routes.PROFILE)
                        },
                        onNavigateToDesks = {
                            navController.navigate(Routes.DESKS)
                        }
                    )
                }

                // Screen 6: Custody Desks
                composable(Routes.DESKS) {
                    CustodyDesksScreen(
                        onBackPressed = {
                            navController.popBackStack()
                        }
                    )
                }

                // Screen 7: Activity & History
                composable(Routes.ACTIVITY) {
                    ActivityScreen(
                        onNavigateToNotifications = {
                            navController.navigate(Routes.NOTIFICATIONS)
                        },
                        onNavigateToProfile = {
                            navController.navigate(Routes.PROFILE)
                        },
                        onNavigateToDesks = {
                            navController.navigate(Routes.DESKS)
                        }
                    )
                }

                // Screen 9: Profile
                composable(Routes.PROFILE) {
                    ProfileScreen(
                        onNavigateToNotifications = {
                            navController.navigate(Routes.NOTIFICATIONS)
                        },
                        onNavigateToActivity = {
                            navController.navigate(Routes.ACTIVITY)
                        },
                        onNavigateToDesks = {
                            navController.navigate(Routes.DESKS)
                        },
                        onNavigateToPreferences = {
                            navController.navigate(Routes.NOTIFICATION_PREFERENCES)
                        },
                        onNavigateToPrivacy = {
                            navController.navigate(Routes.PRIVACY_SECURITY)
                        },
                        onSignOut = {
                            navController.navigate(Routes.LOGIN) {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                    )
                }

                // Screen 5: Notifications
                composable(Routes.NOTIFICATIONS) {
                    NotificationsScreen(
                        onBackPressed = {
                            navController.popBackStack()
                        },
                        onNavigateToDesks = {
                            navController.navigate(Routes.DESKS)
                        },
                        onNavigateToPreferences = {
                            navController.navigate(Routes.NOTIFICATION_PREFERENCES)
                        }
                    )
                }

                // Screen 8: Privacy & Security
                composable(Routes.PRIVACY_SECURITY) {
                    PrivacySecurityScreen(
                        onBackPressed = {
                            navController.popBackStack()
                        }
                    )
                }

                // Screen 10: Notification Preferences
                composable(Routes.NOTIFICATION_PREFERENCES) {
                    NotificationPreferencesScreen(
                        onBackPressed = {
                            navController.popBackStack()
                        }
                    )
                }
            }

            if (showReportDialog) {
                ReportItemDialog(
                    onDismiss = { showReportDialog = false },
                    onReportSubmitted = { newItem ->
                        SampleData.addReport(newItem)
                        showReportDialog = false
                    }
                )
            }
        }
    }
}

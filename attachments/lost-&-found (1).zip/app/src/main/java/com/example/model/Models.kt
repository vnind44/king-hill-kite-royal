package com.example.model

data class CampusReportItem(
    val id: String,
    val title: String,
    val category: String,
    val isLost: Boolean,
    val statusBadge: String,
    val reportedBy: String,
    val location: String,
    val timeAgo: String,
    val imageUrl: String,
    val authClaimCode: String,
    val description: String = "",
    val similarity: Int? = null,
    val matchPercentage: Int? = null,
    val matchDetails: String? = null,
    val isReadyForPickup: Boolean = false,
    val isReturned: Boolean = false,
    val receiptVerifiedText: String? = null
)

data class CustodyDesk(
    val id: String,
    val name: String,
    val location: String,
    val hours: String,
    val isOpen: Boolean = true,
    val tag: String? = null,
    val vaultCount: Int,
    val lockerNote: String? = null,
    val staffName: String? = null,
    val staffRole: String? = null,
    val staffImageUrl: String? = null,
    val isHighValue: Boolean = false,
    val is24Hours: Boolean = false,
    val hasPinLockers: Boolean = true,
    val detailNotes: String? = null
)

data class CampusNotification(
    val id: String,
    val typeBadge: String,
    val title: String,
    val description: String,
    val timeAgo: String,
    val isUrgent: Boolean = false,
    val similarity: Int? = null,
    val imageUrl: String? = null,
    val locationText: String? = null,
    val finderInfo: String? = null,
    val pinCode: String? = null,
    val karmaPointsText: String? = null,
    val isEarlierThisWeek: Boolean = false,
    val hasPinAction: Boolean = false,
    val hasDeskAction: Boolean = false,
    var isRead: Boolean = false
)

data class UserProfile(
    val name: String,
    val role: String,
    val email: String,
    val phone: String,
    val studentId: String,
    val residence: String,
    val karmaPoints: Int,
    val maxKarmaPoints: Int,
    val tier: String,
    val trustScore: Int,
    val itemsReturned: Int,
    val recoveredItems: Int,
    val honorCompliance: Int,
    val falseClaims: Int,
    val avatarUrl: String
)

data class NotificationPreferencesState(
    val smartMatchPush: Boolean = true,
    val aiThreshold: String = "High (80%+)",
    val campusGeofencing: Boolean = true,
    val monitoredZones: Set<String> = setOf("Green Library & Main Quad", "Huang Engineering Complex", "Tressider Student Union"),
    val emailInstantUrgent: Boolean = true,
    val smsAlerts: Boolean = true,
    val soundHaptics: Boolean = true,
    val quietMode: Boolean = true
)

data class PrivacySettingsState(
    val incognitoFinder: Boolean = true,
    val concealDorm: Boolean = true,
    val autoDeleteReceipts: Boolean = true,
    val ssoHighValue: Boolean = true
)

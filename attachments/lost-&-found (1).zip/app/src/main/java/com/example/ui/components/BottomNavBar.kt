package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.SecondaryTeal
import com.example.ui.theme.SurfaceContainerLowest

enum class NavigationTab {
    HOME, SEARCH, REPORT, ACTIVITY, PROFILE
}

@Composable
fun CampusBottomNavBar(
    currentTab: NavigationTab,
    onTabSelected: (NavigationTab) -> Unit,
    onReportClick: () -> Unit
) {
    Surface(
        color = SurfaceContainerLowest.copy(alpha = 0.96f),
        shadowElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                // Home Tab
                NavItem(
                    icon = Icons.Default.Home,
                    label = "Home",
                    isSelected = currentTab == NavigationTab.HOME,
                    testTag = "tab_home",
                    onClick = { onTabSelected(NavigationTab.HOME) }
                )

                // Search Tab
                NavItem(
                    icon = Icons.Default.Search,
                    label = "Search",
                    isSelected = currentTab == NavigationTab.SEARCH,
                    testTag = "tab_search",
                    onClick = { onTabSelected(NavigationTab.SEARCH) }
                )

                // Placeholder space for center elevated Report button
                Spacer(modifier = Modifier.width(52.dp))

                // Activity Tab
                NavItem(
                    icon = Icons.Default.Schedule,
                    label = "Activity",
                    isSelected = currentTab == NavigationTab.ACTIVITY,
                    testTag = "tab_activity",
                    onClick = { onTabSelected(NavigationTab.ACTIVITY) }
                )

                // Profile Tab
                NavItem(
                    icon = Icons.Default.Person,
                    label = "Profile",
                    isSelected = currentTab == NavigationTab.PROFILE,
                    testTag = "tab_profile",
                    onClick = { onTabSelected(NavigationTab.PROFILE) }
                )
            }

            // Center Elevated Report Floating Action Button
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = (-14).dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .shadow(elevation = 6.dp, shape = CircleShape)
                        .clip(CircleShape)
                        .background(SecondaryTeal)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onReportClick() }
                        .testTag("tab_report_fab"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Report Item",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Text(
                    text = "Report",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
    }
}

@Composable
private fun NavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    val tint = if (isSelected) SecondaryTeal else MaterialTheme.colorScheme.onSurfaceVariant
    val fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .defaultMinSize(minWidth = 56.dp, minHeight = 48.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() }
            .testTag(testTag)
            .padding(vertical = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 11.sp,
                fontWeight = fontWeight,
                color = tint
            )
        )
    }
}

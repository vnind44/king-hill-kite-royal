package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.SampleData
import com.example.model.CustodyDesk
import com.example.ui.theme.*

@Composable
fun CustodyDesksScreen(
    onBackPressed: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilterIndex by remember { mutableIntStateOf(0) }
    val filters = listOf("All Desks (4)", "With PIN Lockers", "Open Late")

    var lockerPinInput by remember { mutableStateOf("") }
    var showLockerUnlockSuccess by remember { mutableStateOf(false) }

    var selectedDeskForDetails by remember { mutableStateOf<CustodyDesk?>(null) }
    val context = LocalContext.current

    val desks = SampleData.custodyDesks.filter {
        val matchesSearch = it.name.contains(searchQuery, ignoreCase = true) || it.location.contains(searchQuery, ignoreCase = true)
        val matchesFilter = when (selectedFilterIndex) {
            1 -> it.hasPinLockers
            2 -> it.is24Hours || it.hours.contains("10:00")
            else -> true
        }
        matchesSearch && matchesFilter
    }

    Scaffold(
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = onBackPressed,
                            modifier = Modifier.size(40.dp).testTag("desks_back_btn")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Text(
                            text = "Campus Custody Desks",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 17.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SurfaceContainerLow
                    ) {
                        Text(
                            text = "Stanford Central",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.surface
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Hero Banner: Verified Safe Handoff Network
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PrimaryDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = null,
                            tint = SecondaryFixed,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "VERIFIED SAFE HANDOFF NETWORK",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp,
                                color = SecondaryFixed
                            )
                        )
                    }

                    Text(
                        text = "Official Custody & Lockers",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    )

                    Text(
                        text = "Leave or pick up items securely at staffed campus help desks with digital custody receipts and automated PIN lockers.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = PrimaryFixedDim,
                            lineHeight = 17.sp
                        )
                    )

                    Row(
                        modifier = Modifier.padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text("4 Active Hubs", style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold))
                        Text("•", color = OutlineVariant)
                        Text("27 Items in Vault", style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold))
                        Text("•", color = OutlineVariant)
                        Text("100% Chain of Trust", style = MaterialTheme.typography.labelSmall.copy(color = SecondaryFixed, fontWeight = FontWeight.Bold))
                    }
                }
            }

            // Interactive Campus Map Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Live Campus Desk Network",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Text(
                            text = "Tap a hub pin below",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = SecondaryTeal,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }

                    // Stylized Graphic Campus Map Blueprint
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(SurfaceContainerLow)
                    ) {
                        // Campus map illustration background
                        AsyncImage(
                            model = SampleData.CAMPUS_HERO_URL,
                            contentDescription = "Campus Map Layout",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                            alpha = 0.35f
                        )

                        // 4 Interactive Map Hub Pins
                        // Pin 1: Huang Engineering (Top Left)
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = PrimaryDark,
                            shadowElevation = 4.dp,
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(start = 16.dp, top = 16.dp)
                                .clickable { selectedDeskForDetails = SampleData.custodyDesks[2] }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(SecondaryFixed))
                                Text("Huang Eng", style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold))
                            }
                        }

                        // Pin 2: Green Library (Center)
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = SecondaryTeal,
                            shadowElevation = 6.dp,
                            modifier = Modifier
                                .align(Alignment.Center)
                                .clickable { selectedDeskForDetails = SampleData.custodyDesks[0] }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Star, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                Text("Green Library (Primary)", style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold))
                            }
                        }

                        // Pin 3: Tresidder Union (Bottom Left)
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = PrimaryDark,
                            shadowElevation = 4.dp,
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(start = 24.dp, bottom = 14.dp)
                                .clickable { selectedDeskForDetails = SampleData.custodyDesks[1] }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(SecondaryFixed))
                                Text("Tresidder Union", style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold))
                            }
                        }

                        // Pin 4: SUDPS Police HQ (Bottom Right)
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = PrimaryDark,
                            shadowElevation = 4.dp,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(end = 16.dp, bottom = 14.dp)
                                .clickable { selectedDeskForDetails = SampleData.custodyDesks[3] }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color(0xFFFFB4AB)))
                                Text("SUDPS (24/7)", style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold))
                            }
                        }
                    }
                }
            }

            // Search and Filters
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth().testTag("desks_search_input"),
                placeholder = { Text("Search custody desks or buildings...", style = MaterialTheme.typography.bodyMedium) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Outline) },
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = SurfaceContainerLowest,
                    unfocusedContainerColor = SurfaceContainerLow,
                    focusedBorderColor = SecondaryTeal,
                    unfocusedBorderColor = Color.Transparent
                ),
                singleLine = true
            )

            // Filter Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                filters.forEachIndexed { index, title ->
                    FilterChip(
                        selected = selectedFilterIndex == index,
                        onClick = { selectedFilterIndex = index },
                        label = { Text(title, fontWeight = FontWeight.Bold) },
                        shape = RoundedCornerShape(16.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryDark,
                            selectedLabelColor = Color.White,
                            containerColor = SurfaceContainerLow,
                            labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        border = null
                    )
                }
            }

            // Desks List
            Text(
                text = "VERIFIED CAMPUS DESKS",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
            )

            desks.forEach { desk ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (desk.tag != null) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (desk.tag == "Primary Hub") SecondaryContainer else TertiaryFixed
                                ) {
                                    Text(
                                        text = desk.tag,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = if (desk.tag == "Primary Hub") OnSecondaryContainer else OnTertiaryContainer
                                        ),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            } else {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = SurfaceContainerLow
                                ) {
                                    Text(
                                        text = "STANDARD HUB",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(if (desk.isOpen) SecondaryTeal else ErrorRed)
                                )
                                Text(
                                    text = desk.hours,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (desk.isOpen) SecondaryTeal else ErrorRed
                                    )
                                )
                            }
                        }

                        Text(
                            text = desk.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )

                        Text(
                            text = desk.location,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )

                        // Vault & locker stats
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(SurfaceContainerLow)
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.Inventory2, contentDescription = null, tint = SecondaryTeal, modifier = Modifier.size(16.dp))
                                Text(
                                    text = "${desk.vaultCount} items in vault",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                )
                            }

                            if (desk.lockerNote != null) {
                                Text(
                                    text = desk.lockerNote,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = SecondaryTeal,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }
                        }

                        // Staff and Action
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (desk.staffName != null) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    if (desk.staffImageUrl != null) {
                                        AsyncImage(
                                            model = desk.staffImageUrl,
                                            contentDescription = desk.staffName,
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(CircleShape),
                                            contentScale = ContentScale.Crop
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(CircleShape)
                                                .background(SurfaceContainerHigh),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Person, contentDescription = null, tint = Outline, modifier = Modifier.size(16.dp))
                                        }
                                    }

                                    Column {
                                        Text(
                                            text = desk.staffName,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        )
                                        Text(
                                            text = desk.staffRole ?: "Staff",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 10.sp
                                            )
                                        )
                                    }
                                }
                            } else {
                                Spacer(modifier = Modifier.width(4.dp))
                            }

                            Button(
                                onClick = { selectedDeskForDetails = desk },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (desk.tag == "Primary Hub") SecondaryTeal else PrimaryDark,
                                    contentColor = Color.White
                                )
                            ) {
                                Text(
                                    text = if (desk.tag == "Primary Hub") "Directions & Safe Locker" else "View Desk Details",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }
            }

            // Locker PIN Unlock Box
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.LockClock, contentDescription = null, tint = SecondaryTeal)
                        Text(
                            text = "Have a Locker PIN Code?",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Text(
                        text = "If you have a 6-digit touchless pickup code, enter it below to verify locker clearance at any Stanford smart kiosk.",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = lockerPinInput,
                            onValueChange = { lockerPinInput = it },
                            placeholder = { Text("e.g. 849210") },
                            modifier = Modifier.weight(1f).testTag("locker_pin_input"),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = SurfaceContainerLowest,
                                unfocusedContainerColor = SurfaceContainerLow,
                                focusedBorderColor = SecondaryTeal,
                                unfocusedBorderColor = Color.Transparent
                            ),
                            singleLine = true
                        )

                        Button(
                            onClick = {
                                if (lockerPinInput.isNotBlank()) {
                                    showLockerUnlockSuccess = true
                                } else {
                                    Toast.makeText(context, "Please enter your 6-digit locker PIN", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SecondaryTeal)
                        ) {
                            Text("Unlock Locker", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }

            // After Hours Card
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SurfaceContainerLow,
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.NightlightRound, contentDescription = null, tint = SecondaryTeal, modifier = Modifier.size(20.dp))
                    Text(
                        text = "After-Hours Support: High value items can always be turned in 24/7 at the Department of Public Safety (SUDPS), 711 Serra St.",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                    )
                }
            }
        }
    }

    // Desk Details Modal
    selectedDeskForDetails?.let { desk ->
        AlertDialog(
            onDismissRequest = { selectedDeskForDetails = null },
            title = {
                Text(desk.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(desk.location, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(desk.hours, style = MaterialTheme.typography.labelMedium.copy(color = SecondaryTeal, fontWeight = FontWeight.Bold))
                    Text(desk.detailNotes ?: "Vault secured with 24/7 logging.", style = MaterialTheme.typography.bodySmall)
                    if (desk.hasPinLockers) {
                        Text("• Automated digital touchless pickup lockers equipped.", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("• Student ID verification required at reception.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        Toast.makeText(context, "Directions to ${desk.name} loaded!", Toast.LENGTH_SHORT).show()
                        selectedDeskForDetails = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SecondaryTeal)
                ) {
                    Text("Navigate to Desk")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedDeskForDetails = null }) {
                    Text("Close")
                }
            }
        )
    }

    // Locker Unlock Success Modal
    if (showLockerUnlockSuccess) {
        AlertDialog(
            onDismissRequest = { showLockerUnlockSuccess = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SecondaryTeal)
                    Text("Locker #B-04 Unlocked")
                }
            },
            text = {
                Text(
                    "PIN code verified! Green Library Locker Compartment #B-04 has been opened. Please retrieve your item and close the door firmly.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = { showLockerUnlockSuccess = false },
                    colors = ButtonDefaults.buttonColors(containerColor = SecondaryTeal)
                ) {
                    Text("Done")
                }
            }
        )
    }
}

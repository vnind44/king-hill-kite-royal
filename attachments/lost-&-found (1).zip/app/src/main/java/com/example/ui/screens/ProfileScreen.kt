package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.SampleData
import com.example.ui.components.AuthenticatedAppHeader
import com.example.ui.components.ColorPickerSettingsCard
import com.example.ui.components.FullColorPickerBottomSheet
import com.example.ui.components.HandoverPinSheet
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
    onNavigateToNotifications: () -> Unit,
    onNavigateToActivity: () -> Unit,
    onNavigateToDesks: () -> Unit,
    onNavigateToPreferences: () -> Unit,
    onNavigateToPrivacy: () -> Unit,
    onSignOut: () -> Unit
) {
    var showPinSheet by remember { mutableStateOf(false) }
    var showKarmaDialog by remember { mutableStateOf(false) }
    var showSupportDialog by remember { mutableStateOf(false) }
    var showColorPickerDialog by remember { mutableStateOf(false) }
    val profile = SampleData.defaultProfile
    val context = LocalContext.current

    Scaffold(
        topBar = {
            AuthenticatedAppHeader(
                campusName = "Stanford Central",
                hasUnreadNotifications = true,
                onNotificationsClick = onNavigateToNotifications,
                onProfileClick = {}
            )
        },
        containerColor = MaterialTheme.colorScheme.surface
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Profile Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                        ) {
                            AsyncImage(
                                model = profile.avatarUrl,
                                contentDescription = profile.name,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = profile.name,
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                )
                                Icon(
                                    Icons.Default.Verified,
                                    contentDescription = "Verified Stanford SSO",
                                    tint = SecondaryTeal,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Text(
                                text = profile.role,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            Text(
                                text = "ID: ${profile.studentId} • Axess Synced",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = SecondaryTeal,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }
                    }

                    // Karma Points Progress Bar
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SurfaceContainerLow,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showKarmaDialog = true }
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.Shield, contentDescription = null, tint = SecondaryTeal, modifier = Modifier.size(15.dp))
                                    Text(
                                        text = profile.tier.uppercase(),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = SecondaryTeal
                                        )
                                    )
                                }
                                Text(
                                    text = "${profile.karmaPoints} / ${profile.maxKarmaPoints} pts",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                )
                            }

                            LinearProgressIndicator(
                                progress = { profile.karmaPoints / profile.maxKarmaPoints.toFloat() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = SecondaryTeal,
                                trackColor = SurfaceContainerHigh
                            )

                            Text(
                                text = "80 points until Tier 4 Campus Ambassador",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }

                    // 4 Bento Stats
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BentoStat(label = "Returned", value = "${profile.itemsReturned}", modifier = Modifier.weight(1f))
                        BentoStat(label = "Recovered", value = "${profile.recoveredItems}", modifier = Modifier.weight(1f))
                        BentoStat(label = "Compliance", value = "${profile.honorCompliance}%", modifier = Modifier.weight(1f))
                        BentoStat(label = "False Claims", value = "${profile.falseClaims}", modifier = Modifier.weight(1f))
                    }
                }
            }

            // Quick Actions & Vault
            Text(
                text = "QUICK ACTIONS & VAULT",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickActionCard(
                    icon = Icons.Default.Schedule,
                    title = "Active Reports",
                    subtitle = "3 in progress",
                    onClick = onNavigateToActivity,
                    modifier = Modifier.weight(1f)
                )

                QuickActionCard(
                    icon = Icons.Default.Key,
                    title = "Handover Pass",
                    subtitle = "1 PIN ready",
                    onClick = { showPinSheet = true },
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickActionCard(
                    icon = Icons.Default.Storefront,
                    title = "Safe Desk Hubs",
                    subtitle = "4 Campus Desks",
                    onClick = onNavigateToDesks,
                    modifier = Modifier.weight(1f)
                )

                QuickActionCard(
                    icon = Icons.Default.BookmarkBorder,
                    title = "Watched Items",
                    subtitle = "3 pinned alerts",
                    onClick = { Toast.makeText(context, "3 watched search beacons active", Toast.LENGTH_SHORT).show() },
                    modifier = Modifier.weight(1f)
                )
            }

            // Community Badges
            Text(
                text = "COMMUNITY TRUST BADGES",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    BadgeRow(icon = Icons.Default.ElectricBolt, title = "Swift Return", desc = "Safely returned an item within 2 hours of report.")
                    HorizontalDivider(color = SurfaceContainerLow)
                    BadgeRow(icon = Icons.Default.VerifiedUser, title = "Honest Finder", desc = "100% verified track record confirmed by Campus Police.")
                    HorizontalDivider(color = SurfaceContainerLow)
                    BadgeRow(icon = Icons.Default.LocalLibrary, title = "Green Library Custodian", desc = "Top returner in Main Quad and Green Library.")
                }
            }

            // University SSO Integration Card
            Text(
                text = "UNIVERSITY SSO & SECURITY",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    SettingNavRow(
                        icon = Icons.Default.School,
                        title = "Stanford Axess SSO",
                        subtitle = "Linked • alex.rivera@stanford.edu",
                        actionText = "Active",
                        onClick = {}
                    )

                    HorizontalDivider(color = SurfaceContainerLow)

                    SettingNavRow(
                        icon = Icons.Default.PhoneAndroid,
                        title = "Duo Mobile MFA",
                        subtitle = "Device • Mobile ending in 9102",
                        actionText = "Synced",
                        onClick = {}
                    )

                    HorizontalDivider(color = SurfaceContainerLow)

                    SettingNavRow(
                        icon = Icons.Default.Home,
                        title = "Campus Residence",
                        subtitle = profile.residence,
                        actionText = "Concealed",
                        onClick = onNavigateToPrivacy
                    )
                }
            }

            // Color Picker Tool (Appearance & Screen Background)
            ColorPickerSettingsCard(
                onOpenFullPicker = { showColorPickerDialog = true }
            )

            // App Settings Links
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    SettingNavRow(
                        icon = Icons.Default.Palette,
                        title = "Screen Background Color",
                        subtitle = "Select & apply custom screen canvas color",
                        actionText = AppThemeState.colorToHex(AppThemeState.currentBackgroundColor),
                        onClick = { showColorPickerDialog = true }
                    )

                    HorizontalDivider(color = SurfaceContainerLow)

                    SettingNavRow(
                        icon = Icons.Default.NotificationsNone,
                        title = "Notification & Match Beacons",
                        subtitle = "Smart AI push, Geofences, Quiet Mode",
                        actionText = "Configure",
                        onClick = onNavigateToPreferences
                    )

                    HorizontalDivider(color = SurfaceContainerLow)

                    SettingNavRow(
                        icon = Icons.Default.Lock,
                        title = "Privacy & Claim Concealment",
                        subtitle = "Incognito finder, serial number masking",
                        actionText = "Manage",
                        onClick = onNavigateToPrivacy
                    )

                    HorizontalDivider(color = SurfaceContainerLow)

                    SettingNavRow(
                        icon = Icons.Default.Headphones,
                        title = "Campus Safety & Support Line",
                        subtitle = "24/7 SUDPS Dispatch & Help Desks",
                        actionText = "Contact",
                        onClick = { showSupportDialog = true }
                    )
                }
            }

            // Sign Out Button
            OutlinedButton(
                onClick = onSignOut,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("sign_out_btn"),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, ErrorRed),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed)
            ) {
                Icon(Icons.Default.Logout, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sign Out of Stanford SSO", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Support Modal
    if (showSupportDialog) {
        AlertDialog(
            onDismissRequest = { showSupportDialog = false },
            title = { Text("Campus Safety & Support") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("• Stanford Police (SUDPS): (650) 723-9633")
                    Text("• Non-Emergency Dispatch: 24/7 Available")
                    Text("• Green Library Lost & Found Desk: (650) 725-1064")
                    Text("• Tresidder Union Info Desk: (650) 725-8200")
                }
            },
            confirmButton = {
                Button(onClick = { showSupportDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = PrimaryDark)) {
                    Text("Close")
                }
            }
        )
    }

    // Karma Rules Modal
    if (showKarmaDialog) {
        AlertDialog(
            onDismissRequest = { showKarmaDialog = false },
            title = { Text("Campus Karma & Trust Score") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("How Campus Karma works:", fontWeight = FontWeight.Bold)
                    Text("• +50 pts: Turning in a found item at a safe desk")
                    Text("• +25 pts: Quick handover verification with PIN")
                    Text("• +10 pts: Confirming an accurate match report")
                    Text("• Tier 4 Ambassador: Unlocks priority vault lockers and direct student messenger clearance.")
                }
            },
            confirmButton = {
                Button(onClick = { showKarmaDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = SecondaryTeal)) {
                    Text("Got it")
                }
            }
        )
    }

    // Handover PIN Sheet
    if (showPinSheet) {
        HandoverPinSheet(
            pinCode = "849 - 210",
            itemName = "Active Handover Pass",
            deskName = "Green Library Custody Desk",
            onDismiss = { showPinSheet = false }
        )
    }

    // Custom Color Picker Tool Bottom Sheet / Dialog
    if (showColorPickerDialog) {
        FullColorPickerBottomSheet(
            onDismiss = { showColorPickerDialog = false }
        )
    }
}

@Composable
private fun BentoStat(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = SurfaceContainerLow,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}

@Composable
private fun QuickActionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(SecondaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = OnSecondaryContainer, modifier = Modifier.size(18.dp))
            }
            Text(text = title, style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp))
        }
    }
}

@Composable
private fun BadgeRow(icon: ImageVector, title: String, desc: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(SurfaceContainerLow),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = SecondaryTeal, modifier = Modifier.size(20.dp))
        }
        Column {
            Text(text = title, style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Text(text = desc, style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp))
        }
    }
}

@Composable
private fun SettingNavRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    actionText: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(icon, contentDescription = null, tint = SecondaryTeal, modifier = Modifier.size(20.dp))
            Column {
                Text(text = title, style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp))
            }
        }
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = SurfaceContainerLow
        ) {
            Text(
                text = actionText,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = SecondaryTeal
                ),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

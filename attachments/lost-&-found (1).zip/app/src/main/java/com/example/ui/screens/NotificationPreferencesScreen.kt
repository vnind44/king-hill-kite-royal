package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NotificationPreferencesState
import com.example.ui.theme.*

@Composable
fun NotificationPreferencesScreen(
    onBackPressed: () -> Unit
) {
    var prefs by remember { mutableStateOf(NotificationPreferencesState()) }
    var emailType by remember { mutableStateOf("Instant Urgent") } // or "Daily Digest"
    var claimStatusAlerts by remember { mutableStateOf(true) }
    var safeDeskCustodyAlerts by remember { mutableStateOf(true) }
    var lockerPinExpiryAlerts by remember { mutableStateOf(true) }
    val context = LocalContext.current

    val zones = listOf(
        "Green Library & Main Quad",
        "Huang Engineering Complex",
        "Tressider Student Union",
        "Arrillaga Dining & Gym",
        "Crothers Hall & East Campus"
    )

    Scaffold(
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = onBackPressed,
                            modifier = Modifier.size(40.dp).testTag("prefs_back_btn")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Text(
                            text = "Notification Preferences",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 17.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.Radar,
                        contentDescription = null,
                        tint = SecondaryTeal,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.surface
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Hero Status Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PrimaryDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Radar, contentDescription = null, tint = SecondaryFixed, modifier = Modifier.size(22.dp))
                    }

                    Column {
                        Text(
                            text = "Proximity Engine: Active",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Color.White)
                        )
                        Text(
                            text = "AI monitors reports within 500m of your registered classes and study halls.",
                            style = MaterialTheme.typography.bodySmall.copy(color = PrimaryFixedDim, fontSize = 11.sp)
                        )
                    }
                }
            }

            // SMART MATCH BEACONS
            Text(
                text = "SMART MATCH BEACONS",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Instant Match Push Alerts", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                            Text(
                                "Receive an immediate alert when an item matching your description is reported.",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                            )
                        }
                        Switch(
                            checked = prefs.smartMatchPush,
                            onCheckedChange = { prefs = prefs.copy(smartMatchPush = it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SecondaryTeal)
                        )
                    }

                    HorizontalDivider(color = SurfaceContainerLow)

                    // AI Similarity Threshold
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("AI Similarity Threshold", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("Relaxed (60%)", "High (80%+)", "Strict (95%)").forEach { threshold ->
                                val isSelected = prefs.aiThreshold == threshold
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) PrimaryDark else SurfaceContainerLow,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { prefs = prefs.copy(aiThreshold = threshold) }
                                ) {
                                    Box(
                                        modifier = Modifier.padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = threshold,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                                fontSize = 10.sp
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // CAMPUS ZONE GEOFENCING
            Text(
                text = "CAMPUS ZONE GEOFENCING",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Zone-Based Proximity", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                            Text(
                                "Prioritize notifications for locations where you spend the most time.",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                            )
                        }
                        Switch(
                            checked = prefs.campusGeofencing,
                            onCheckedChange = { prefs = prefs.copy(campusGeofencing = it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SecondaryTeal)
                        )
                    }

                    HorizontalDivider(color = SurfaceContainerLow)

                    // Checklist
                    zones.forEach { zone ->
                        val isChecked = prefs.monitoredZones.contains(zone)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val newSet = prefs.monitoredZones.toMutableSet()
                                    if (isChecked) newSet.remove(zone) else newSet.add(zone)
                                    prefs = prefs.copy(monitoredZones = newSet)
                                }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { checked ->
                                    val newSet = prefs.monitoredZones.toMutableSet()
                                    if (checked) newSet.add(zone) else newSet.remove(zone)
                                    prefs = prefs.copy(monitoredZones = newSet)
                                },
                                colors = CheckboxDefaults.colors(checkedColor = SecondaryTeal)
                            )
                            Text(
                                text = zone,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 13.sp
                                )
                            )
                        }
                    }
                }
            }

            // HANDOVER & CLAIM UPDATES
            Text(
                text = "HANDOVER & CUSTODY UPDATES",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Claim Status Approvals", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium))
                        Switch(
                            checked = claimStatusAlerts,
                            onCheckedChange = { claimStatusAlerts = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SecondaryTeal)
                        )
                    }

                    HorizontalDivider(color = SurfaceContainerLow)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Safe Desk Officer Custody Logs", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium))
                        Switch(
                            checked = safeDeskCustodyAlerts,
                            onCheckedChange = { safeDeskCustodyAlerts = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SecondaryTeal)
                        )
                    }

                    HorizontalDivider(color = SurfaceContainerLow)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Locker PIN Expiration Reminders", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium))
                        Switch(
                            checked = lockerPinExpiryAlerts,
                            onCheckedChange = { lockerPinExpiryAlerts = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SecondaryTeal)
                        )
                    }
                }
            }

            // DELIVERY CHANNELS
            Text(
                text = "DELIVERY CHANNELS",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("SMS & Duo Mobile Push Alerts", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                            Text("Send critical PIN codes and matches via Duo push.", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp))
                        }
                        Switch(
                            checked = prefs.smsAlerts,
                            onCheckedChange = { prefs = prefs.copy(smsAlerts = it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SecondaryTeal)
                        )
                    }

                    HorizontalDivider(color = SurfaceContainerLow)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("In-App Sound & Haptics", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                            Text("Vibrate phone on new radar match.", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp))
                        }
                        Switch(
                            checked = prefs.soundHaptics,
                            onCheckedChange = { prefs = prefs.copy(soundHaptics = it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SecondaryTeal)
                        )
                    }
                }
            }

            // QUIET HOURS
            Text(
                text = "EXAM & SLEEP QUIET HOURS",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Do Not Disturb Mode", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                            Text("11:00 PM – 8:00 AM PST • High priority PINs bypass silence.", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp))
                        }
                        Switch(
                            checked = prefs.quietMode,
                            onCheckedChange = { prefs = prefs.copy(quietMode = it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SecondaryTeal)
                        )
                    }
                }
            }

            // Save Preferences Button
            Button(
                onClick = {
                    Toast.makeText(context, "Preferences saved successfully!", Toast.LENGTH_SHORT).show()
                    onBackPressed()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_prefs_btn"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SecondaryTeal)
            ) {
                Text("Save Preferences", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

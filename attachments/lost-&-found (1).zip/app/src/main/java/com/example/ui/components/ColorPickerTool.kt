package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AppThemeState
import com.example.ui.theme.PrimaryDark
import com.example.ui.theme.SecondaryTeal
import com.example.ui.theme.SurfaceContainerHigh
import com.example.ui.theme.SurfaceContainerLowest

@Composable
fun ColorPickerSettingsCard(
    modifier: Modifier = Modifier,
    onOpenFullPicker: () -> Unit = {}
) {
    val currentColor = AppThemeState.currentBackgroundColor
    val animatedBg by animateColorAsState(targetValue = currentColor, label = "bg_preview")
    val isDark = AppThemeState.isDarkBackground
    val context = LocalContext.current

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceContainerLowest),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("color_picker_settings_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(SecondaryTeal),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = "Theme Color",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Screen Background Color",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Text(
                            text = "Instantly customizes app background canvas",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }

                // Active Color Swatch Pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = animatedBg,
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.clickable { onOpenFullPicker() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(if (isDark) Color.White else Color.Black)
                        )
                        Text(
                            text = AppThemeState.colorToHex(currentColor),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) Color.White else Color(0xFF0B1C30)
                            )
                        )
                    }
                }
            }

            // Quick Preset Row
            Text(
                text = "POPULAR BACKGROUND PRESETS",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 0.8.sp,
                    color = SecondaryTeal
                )
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AppThemeState.presets.forEach { preset ->
                    val isSelected = AppThemeState.colorToHex(currentColor) == AppThemeState.colorToHex(preset.color)
                    val presetIsDark = (preset.color.red * 0.299f + preset.color.green * 0.587f + preset.color.blue * 0.114f) < 0.5f

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = preset.color,
                        border = BorderStroke(
                            width = if (isSelected) 2.5.dp else 1.dp,
                            color = if (isSelected) SecondaryTeal else MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier
                            .clickable {
                                AppThemeState.setBackgroundColor(preset.color)
                                Toast.makeText(context, "${preset.name} applied!", Toast.LENGTH_SHORT).show()
                            }
                            .testTag("preset_${preset.name.lowercase().replace(' ', '_')}")
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(preset.color)
                                    .border(1.dp, Color.Gray.copy(alpha = 0.3f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = if (presetIsDark) Color.White else PrimaryDark,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            Text(
                                text = preset.name,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (presetIsDark) Color.White else Color(0xFF0B1C30)
                                )
                            )
                        }
                    }
                }
            }

            // Quick Actions & Launch Custom Mixer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = {
                        AppThemeState.resetToDefault()
                        Toast.makeText(context, "Reset to default background", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("reset_bg_color_btn")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Reset Default", style = MaterialTheme.typography.labelMedium)
                }

                Button(
                    onClick = onOpenFullPicker,
                    colors = ButtonDefaults.buttonColors(containerColor = SecondaryTeal),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("open_color_mixer_btn")
                ) {
                    Icon(Icons.Default.ColorLens, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Color Mixer Tool", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                }
            }
        }
    }
}

@Composable
fun FullColorPickerBottomSheet(
    onDismiss: () -> Unit
) {
    val currentColor = AppThemeState.currentBackgroundColor
    var redValue by remember(currentColor) { mutableFloatStateOf(currentColor.red * 255f) }
    var greenValue by remember(currentColor) { mutableFloatStateOf(currentColor.green * 255f) }
    var blueValue by remember(currentColor) { mutableFloatStateOf(currentColor.blue * 255f) }
    var hexInput by remember(currentColor) { mutableStateOf(AppThemeState.colorToHex(currentColor)) }

    val context = LocalContext.current
    val liveColor = Color(
        red = (redValue / 255f).coerceIn(0f, 1f),
        green = (greenValue / 255f).coerceIn(0f, 1f),
        blue = (blueValue / 255f).coerceIn(0f, 1f),
        alpha = 1f
    )
    val isDark = (liveColor.red * 0.299f + liveColor.green * 0.587f + liveColor.blue * 0.114f) < 0.5f

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ColorLens,
                    contentDescription = null,
                    tint = SecondaryTeal
                )
                Text(
                    text = "Background Color Picker",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Live preview banner
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = liveColor,
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Live Background Preview",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) Color.White else Color(0xFF0B1C30)
                                )
                            )
                            Text(
                                text = "${AppThemeState.colorToHex(liveColor)} • ${if (isDark) "Dark Theme" else "Light Theme"}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isDark) Color(0xFFE2E8F0) else Color(0xFF334155)
                                )
                            )
                        }
                    }
                }

                // Spectrum quick hue strip
                Text(
                    text = "QUICK SPECTRUM HUES",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
                val spectrumGradient = Brush.horizontalGradient(
                    listOf(
                        Color(0xFFFF0000),
                        Color(0xFFFF7F00),
                        Color(0xFFFFFF00),
                        Color(0xFF00FF00),
                        Color(0xFF00FFFF),
                        Color(0xFF0000FF),
                        Color(0xFF8B00FF),
                        Color(0xFFFF007F),
                        Color(0xFFFFFFFF),
                        Color(0xFF000000)
                    )
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(24.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(spectrumGradient)
                )

                // Quick hue taps
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        Color(0xFFF8F9FF),
                        Color(0xFFFFFBEB),
                        Color(0xFFF0FDF4),
                        Color(0xFFE0F2FE),
                        Color(0xFFF3E8FF),
                        Color(0xFFFFE4E6),
                        Color(0xFFFEF3C7),
                        Color(0xFFE2E8F0),
                        Color(0xFF0F172A),
                        Color(0xFF0B1C30),
                        Color(0xFF1B2A26),
                        Color(0xFF2E1065)
                    ).forEach { col ->
                        val isCurr = AppThemeState.colorToHex(col) == AppThemeState.colorToHex(liveColor)
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(col)
                                .border(
                                    width = if (isCurr) 2.5.dp else 1.dp,
                                    color = if (isCurr) SecondaryTeal else Color.LightGray,
                                    shape = CircleShape
                                )
                                .clickable {
                                    redValue = col.red * 255f
                                    greenValue = col.green * 255f
                                    blueValue = col.blue * 255f
                                    hexInput = AppThemeState.colorToHex(col)
                                    // Instantly apply to app background!
                                    AppThemeState.setBackgroundColor(col)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isCurr) {
                                val cDark = (col.red * 0.299f + col.green * 0.587f + col.blue * 0.114f) < 0.5f
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = if (cDark) Color.White else PrimaryDark,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                HorizontalDivider(color = SurfaceContainerHigh)

                // RGB Sliders - interactive real-time tuning
                Text(
                    text = "RGB CHANNELS (LIVE ADJUSTMENT)",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )

                // Red Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Red", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold, color = Color(0xFFDC2626)))
                        Text("${redValue.toInt()}", style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace))
                    }
                    Slider(
                        value = redValue,
                        onValueChange = {
                            redValue = it
                            val updated = Color((redValue / 255f), (greenValue / 255f), (blueValue / 255f))
                            hexInput = AppThemeState.colorToHex(updated)
                            AppThemeState.setBackgroundColor(updated) // Instant application!
                        },
                        valueRange = 0f..255f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFDC2626),
                            activeTrackColor = Color(0xFFEF4444)
                        ),
                        modifier = Modifier.testTag("slider_red")
                    )
                }

                // Green Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Green", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold, color = Color(0xFF16A34A)))
                        Text("${greenValue.toInt()}", style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace))
                    }
                    Slider(
                        value = greenValue,
                        onValueChange = {
                            greenValue = it
                            val updated = Color((redValue / 255f), (greenValue / 255f), (blueValue / 255f))
                            hexInput = AppThemeState.colorToHex(updated)
                            AppThemeState.setBackgroundColor(updated) // Instant application!
                        },
                        valueRange = 0f..255f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF16A34A),
                            activeTrackColor = Color(0xFF22C55E)
                        ),
                        modifier = Modifier.testTag("slider_green")
                    )
                }

                // Blue Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Blue", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold, color = Color(0xFF2563EB)))
                        Text("${blueValue.toInt()}", style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace))
                    }
                    Slider(
                        value = blueValue,
                        onValueChange = {
                            blueValue = it
                            val updated = Color((redValue / 255f), (greenValue / 255f), (blueValue / 255f))
                            hexInput = AppThemeState.colorToHex(updated)
                            AppThemeState.setBackgroundColor(updated) // Instant application!
                        },
                        valueRange = 0f..255f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF2563EB),
                            activeTrackColor = Color(0xFF3B82F6)
                        ),
                        modifier = Modifier.testTag("slider_blue")
                    )
                }

                // Hex Input Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = hexInput,
                        onValueChange = {
                            hexInput = it
                            val parsed = AppThemeState.hexToColor(it)
                            if (parsed != null) {
                                redValue = parsed.red * 255f
                                greenValue = parsed.green * 255f
                                blueValue = parsed.blue * 255f
                                AppThemeState.setBackgroundColor(parsed) // Instant application!
                            }
                        },
                        label = { Text("HEX Color Code") },
                        placeholder = { Text("#FFFFFF") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("hex_color_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Button(
                        onClick = {
                            val parsed = AppThemeState.hexToColor(hexInput)
                            if (parsed != null) {
                                AppThemeState.setBackgroundColor(parsed)
                                Toast.makeText(context, "Color applied: $hexInput", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Invalid HEX code (use e.g. #F0F4F8)", Toast.LENGTH_SHORT).show()
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SecondaryTeal)
                    ) {
                        Text("Apply")
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    AppThemeState.setBackgroundColor(liveColor)
                    Toast.makeText(context, "Background color active: ${AppThemeState.colorToHex(liveColor)}", Toast.LENGTH_SHORT).show()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = SecondaryTeal),
                modifier = Modifier.testTag("confirm_color_btn")
            ) {
                Text("Done", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    AppThemeState.resetToDefault()
                    Toast.makeText(context, "Reset to default background", Toast.LENGTH_SHORT).show()
                    onDismiss()
                }
            ) {
                Text("Reset Default")
            }
        }
    )
}

package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Campus Compass Design System Colors
val SurfaceColor = Color(0xFFF8F9FF)
val SurfaceDim = Color(0xFFCBDBF5)
val SurfaceBright = Color(0xFFF8F9FF)
val SurfaceContainerLowest = Color(0xFFFFFFFF)
val SurfaceContainerLow = Color(0xFFEFF4FF)
val SurfaceContainer = Color(0xFFE5EEFF)
val SurfaceContainerHigh = Color(0xFFDCE9FF)
val SurfaceContainerHighest = Color(0xFFD3E4FE)

val OnSurface = Color(0xFF0B1C30)
val OnSurfaceVariant = Color(0xFF45464D)
val InverseSurface = Color(0xFF213145)
val InverseOnSurface = Color(0xFFEAF1FF)

val Outline = Color(0xFF76777D)
val OutlineVariant = Color(0xFFC6C6CD)
val SurfaceTint = Color(0xFF565E74)

val PrimaryDark = Color(0xFF0B1C30)
val PrimaryContainer = Color(0xFF131B2E)
val OnPrimary = Color(0xFFFFFFFF)
val OnPrimaryContainer = Color(0xFF7C839B)
val PrimaryFixedDim = Color(0xFF9AA7BF)

// Trust Teal / Emerald
val SecondaryTeal = Color(0xFF006A61)
val OnSecondary = Color(0xFFFFFFFF)
val SecondaryContainer = Color(0xFF86F2E4)
val OnSecondaryContainer = Color(0xFF006F66)
val SecondaryFixed = Color(0xFF89F5E7)
val SecondaryFixedDim = Color(0xFF6BD8CB)

// Tertiary Green accents
val TertiaryFixed = Color(0xFF85F8C4)
val TertiaryFixedDim = Color(0xFF68DBA9)
val OnTertiaryContainer = Color(0xFF069669)

// Errors
val ErrorRed = Color(0xFFBA1A1A)
val ErrorContainer = Color(0xFFFFDAD6)
val OnErrorContainer = Color(0xFF93000A)

